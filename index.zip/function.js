$(document).ready(function(){
// menu slide function//
$("#mobile-menu-button").click(function(){
  $("#mobile-menu").toggleClass("menu-sidebar menu-sidebar-show")
})



// Document.ready End here//
})
