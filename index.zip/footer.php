<div class="container-fluid">
  <div class="d-block d-lg-none fixed-footer">
    <div class="row text-center">
      <div class="col-3">
        <a href="#"><img src="images/settings.png" alt="message" class="img-responsive icon"></a>
      </div>
      <div class="col-3">
        <a href="#"><img src="images/settings.png" alt="message" class="img-responsive icon"></a>
      </div>
      <div class="col-3">
        <a href="#"><img src="images/settings.png" alt="message" class="img-responsive icon"></a>
      </div>
      <div class="col-3">
        <a href="#"><img src="images/settings.png" alt="message" class="img-responsive icon"></a>
      </div>
    </div>
  </div>  
</div>
<!-- Javascrit and other libraries -->
<?php require_once "includes/libraries.php"; ?>
</body>
</html>
