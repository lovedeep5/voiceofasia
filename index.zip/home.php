<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="includes/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <title>VOICE OF ASIA</title>
  </head>
  <body>
    <div class="container">
      <div class="row justify-content-md-center">
    <div class="col-xl-12 co12-lg-12 col-md-12 col-sm-12">
    <div class="header">
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <img src="images/Logo.png" alt="Logo" class="img-fluid">
        </div>
      </div>
    </div>
    </div>
    </div>
    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
    <div class="welcome-content">
      <div class="container">
        <div class="row welcome-logo">
          <div class="col-12 text-center">
            <img src="images/Welcome-screen.png" alt="welcome Logo" class="img-fluid">
          </div>
        </div>
      </div>
    </div>
    <div class="welcome-controle mt-50px">
      <div class="container">
        <div class="row text-center">
          <div class="col-xl-6 col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <a href="#" class="btn btn-lg btn-outline-danger button-100 mt-10"> Signup</a>
          </div>
          <div class="col-xl-6 col-lg-12 col-md-6 col-sm-6 col-xs-12">
            <a href="user-home.php" class="btn btn-lg btn-outline-danger button-100 mt-10">Login</a>
          </div>
        </div>
        <div class="col-12 text-center mt-10">
          <a href="#"><p>Terms and condition*</p></a>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>
    <?php require_once "includes/libraries.php"; ?>
  </body>
</html>
