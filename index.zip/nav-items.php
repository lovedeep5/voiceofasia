<a href="#"><li>Home</li></a>
<a href="#"><li>Mentores</li></a>
<a href="#"><li>Mentees</li></a>
<a href="#"><li>My Learning</li></a>
<a href="#"><li>Recomended Mentors</li></a>
<a href="#"><li>Log Out</li></a>
